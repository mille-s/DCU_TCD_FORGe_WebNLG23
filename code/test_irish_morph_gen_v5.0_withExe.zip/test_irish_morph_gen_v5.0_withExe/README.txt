AFTER YOU UNZIP TO A FOLDER ON UBUNTU YOU SHOULD MAKE flookup EXECUTABLE.
THEN RUN THE FOLLOWING COMMAND:
$cat aerfort_gen_test.txt | flookup -a allgen.fst

YOU SHOULD GET THIS OUTPUT:

is+Cop+Pres	is

é+Pron+Pers+3P+Sg+Masc	é

1200m		+?

fad+Noun+Masc+Com+Sg	fad

príomh+Prefix	príomh-

rúidbhealach+Noun+Masc+Com+Sg	rúidbhealach

Aerfort+Noun+Masc+Com+Sg+Len	+?

Baile_Átha_Cliath+Prop+Noun+Masc+Gen+Sg+Len	Bhaile Átha Cliath

.	+?

OUTPUT "+?" MEANS THAT THE INPUT IS NOT RECOGNISED BY THE GENERATOR. IN SUCH CASES MAYBE YOU COULD USE THE INPUT WORD AS IS e.g. "1200m" etc.


YOU CAN USE -X FLAG TO HIDE THE INPUT:

$cat aerfort_gen_test.txt | flookup -ax allgen.fst
YOU SHOULD GET THIS OUTPUT:

is

é

+?

fad

príomh-

rúidbhealach

+?

Bhaile Átha Cliath

+?

BUT MAYBE THIS IS NOT AS USEFUL?

Elaine 10-02-2003
